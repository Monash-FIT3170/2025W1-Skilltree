import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Post,
	UseGuards,
} from '@nestjs/common';
import { PostService } from './post.service';
import { CreatePostDto } from './dto/create-post.dto';
import { JwtGuard } from 'src/_utils/guards';
import { GetUser } from 'src/_utils/decorator';
import { User } from '@prisma/client';

@Controller('post')
export class PostController {
	constructor(private postService: PostService) {}

	@Get()
	async getAllPosts() {
		return this.postService.getAllPosts();
	}

	@Get(':id')
	async getPostById(@Param('id') id: string) {
		return this.postService.getPostById(id);
	}

	@UseGuards(JwtGuard)
	@Post()
	async createPost(@Body() dto: CreatePostDto, @GetUser() user: User) {
		return this.postService.createPost(dto, user);
	}

	@UseGuards(JwtGuard)
	@Delete(':id')
	async deletePost(@Param('id') id: string, @GetUser() user: User) {
		return this.postService.deletePost(id, user);
	}

	@Post('like/:postId')
	@UseGuards(JwtGuard)
	async likePost(@Param('postId') id: string) {
		return this.postService.likePost(id);
	}

	@Post('unlike/:postId')
	@UseGuards(JwtGuard)
	async unlikepost(@Param('postId') id: string) {
		return this.postService.unlikePost(id);
	}
}
