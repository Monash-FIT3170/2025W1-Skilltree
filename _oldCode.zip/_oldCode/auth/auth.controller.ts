import { Body, Controller, Patch, Post, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { ForgotPasswordDto, SignInDto, SignUpDto } from './dto';
import { JwtGuard } from 'src/_utils/guards';
import { User } from '@prisma/client';
import { GetUser } from '../../src/_utils/decorator';

@Controller('auth')
export class AuthController {
	constructor(private authService: AuthService) {}

	@Post('signin')
	signin(@Body() dto: SignInDto) {
		return this.authService.signin(dto);
	}

	@Post('signup')
	signup(@Body() dto: SignUpDto) {
		return this.authService.signup(dto);
	}

	@UseGuards(JwtGuard)
	@Patch('forgot-password')
	forgotPassword(@GetUser() user: User, @Body() dto: ForgotPasswordDto) {
		return this.authService.forgotPassword(user, dto);
	}
}
